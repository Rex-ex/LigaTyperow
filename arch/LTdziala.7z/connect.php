<?php
$serverName = 'localhost';
$userName = 'root';
$pwd = '';
$tableName = 'lt_ms_2018';
$conn = new mysqli($serverName, $userName, $pwd, $tableName);
?>
