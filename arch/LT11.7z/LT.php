<!DOCTYPE HTML>
<html lang="pl">
<head>
  <meta charset="UTF-8" />
  <title>Liga Typerów 2018</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="" />
  <meta name="author" content="Maro" />
  <link rel='stylesheet' href='style/main.css' type='text/css' />
  <link rel='stylesheet' href='style/flags.css' type='text/css' />
</head>
<body>
<div class="wrapper">
  <h1>Liga Typerów 2018</h1>
<?php
  //base connect
  include('connect.php');
  	if ($conn == true){
  		echo "<div class='emo'><img src='img/emo_smile.jpg' alt='connect correct!'/></div>";
    } else {
  		echo "<div class='emo'><img src='img/emo_sad.png' alt='connect fail!' /></div>";
  		echo "<h4>Proszę poinformuj administratora!</h4>";
      die("Nie udalo sie polaczyc!. Blad: ".$conn->mysqli_connect_error);
  	}
  //base connect end
  //query - show main table
  mysqli_query($conn, "set names utf8");
  $query1 = "SELECT tgame.Date, tgame.IDGame, tteams.TeamName as `Gospodarze`
            FROM tgame
            INNER JOIN tteams ON tgame.HomeTeam = tteams.IDTeam
            ORDER BY tgame.IDGame;";
  $query2 = "SELECT tteams.TeamName as `Goście`
            FROM tgame
            INNER JOIN tteams ON tgame.AwayTeam = tteams.IDTeam
            ORDER BY tgame.IDGame;";
  $query3 = "SELECT IFNULL(tgame.HomeGoal, '---') AS gol1, IFNULL(tgame.AwayGoal, '---') AS gol2
            FROM tgame;";
  //flags id's
  $query4 = "SELECT tteams.AliasCss AS flag
            FROM tteams;";
  //
  $result1 = mysqli_query($conn, $query1);
  $result2 = mysqli_query($conn, $query2);
  $result3 = mysqli_query($conn, $query3);
  $result4 = mysqli_query($conn, $query4);
  $rows_num =  mysqli_num_rows($result1);

 // var_dump($table);
?>
  <table>
    <tr>
      <th>Data</th>
      <th>Mecz #</th>
      <th>Gospodarz</th>
      <th>Gość</th>
      <th>Wynik</th>
      <th>Michał</th>
      <th>Marek</th>
    </tr>
<img src="img/blank.gif" class="flag flag-cz" alt="Czech Republic" />
<?php
  // $row2 = mysqli_fetch_assoc($result2);
  $row1 = mysqli_fetch_assoc($result1);
  $row2 = mysqli_fetch_assoc($result2);
  $row3 = mysqli_fetch_assoc($result3);
  $row4 = mysqli_fetch_assoc($result4);
  for ($i=0; $i<=$rows_num; $i++) {
    $originalDate = $row1['Date'];
    $newDate = date("d-m-Y", strtotime($originalDate));
    echo "<tr>"
      ."<td>".$newDate."</td>"
      ."<td>".$row1["IDGame"]."</td>"
      ."<td>"."<img src='img/blank.gif' class='flag flag-".$row4['flag']."' />".$row1["Gospodarze"]."</td>"
      ."<td>".$row2['Goście']."</td>"
      ."<td>".$row3['gol1']." : ".$row3['gol2']."</td>"


      ."</tr>";
  }






?>
  </table>
</div>
</body>
</html>
