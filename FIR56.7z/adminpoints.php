<!DOCTYPE HTML>
<html lang="pl">
<head>
  <meta charset="UTF-8" />
  <title>Admin: Typy - UPDATE</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <META NAME="robots" CONTENT="noindex,nofollow">
  <meta name="description" content="" />
  <meta name="author" content="Maro" />
  <link rel='stylesheet' href='style/main.css' type='text/css' />
</head>
<body>
<div class="wrapper">

  <form action="addPoints.php" method="post">
    <label for="pwd">PWD:</label>
    <input type="password" name="pwd">
    <br />
    <label for="UPD_types">Przycisk - przyznaj punkty za mecze:</label>
    <br />
    <input class= 'green 'type="submit" name="UPD_types" value="UPDATE Typy">
  </form>






</div>

</body>
</html>
