<?php
$serverName = 'localhost';
$userName = 'root';
$pwd = '';
$tableName = 'mmanczak_lt';
$conn = new mysqli($serverName, $userName, $pwd, $tableName);
?>
